from openpyxl import load_workbook
from xlrd import open_workbook
from xlutils.copy import copy
wb=open_workbook('./newsheet1.xls')
nb=copy(wb)#copy the original workbook in a new workboook
ns=nb.get_sheet(0)
s=wb.sheet_by_index(0);
max_percent=0
mood=['angry','disgust','fear','happy','sad','surprise','neutral']
for i in range(1,72):
	max_percent=s.cell(i,1).value
	k=1
	for j in range(2,8):
		if s.cell(i,j).value > max_percent:
			max_percent=s.cell(i,j).value
			k=j
	ns.write(i,8,mood[k-1])
nb.save('./mood_classified_videos.xls')