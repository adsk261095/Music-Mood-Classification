#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  3 15:36:49 2017

@author: adam
"""

import cv2
import numpy as np
from keras.models import load_model
import h5py
from openpyxl import load_workbook
from xlrd import open_workbook
from xlutils.copy import copy
import os

path = 'D:/AMAN/Capstone/scripts/video/dataset_videos'
wb=open_workbook('D:/AMAN/Capstone/scripts/video/Songs_Database_300.xlsx')
nb=copy(wb)#copy the original workbook in a new workboook
ns=nb.get_sheet(0)
s=wb.sheet_by_index(0);
faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_alt2.xml')
# h5py.File('keras_model/model_5-49-0.62.hdf5','r')
model = load_model('keras_model/model_5-49-0.62.hdf5')
target = ['angry','disgust','fear','happy','sad','surprise','neutral']
for i in range(10,20):
    if os.path.isfile(os.path.join(path,s.cell(i,1).value+'.mp4')):
        file=s.cell(i,1).value+'.mp4'
    else:
        file=s.cell(i,1).value+'.webm'
    print('a')
    print('a')
    print('a')
    print('a')
    print('a')
    print(os.path.join(path,file))
    file='D:/AMAN/Capstone/scripts/video/dataset_videos/'+file
    # print(file)
    # print('D:/AMAN/Capstone/facial_emotion_recognition/dataset_video/Mere saamne wali khidki.mp4')
    # # if 'D:/AMAN/Capstone/facial_emotion_recognition/dataset_video/Mere saamne wali khidki.mp4'==('D:/AMAN/Capstone/facial_emotion_recognition/dataset_video/'+file):
    #     print('yes')
    video_capture = cv2.VideoCapture(file)
    font = cv2.FONT_HERSHEY_SIMPLEX
    angry=0
    disgust=0
    fear=0
    happy=0
    sad=0
    surprise=0
    neutral=0
    total=1
    frame_count=0

    index = int(s.cell(i,3).value[-2])
    print(index)
    start_time = index*60*1000
    print(start_time)
    stop_time = (index+1)*60*1000

    while True:
        try:
            # Capture frame-by-frame
            ret, frame = video_capture.read()
            
            if video_capture.get(cv2.CAP_PROP_POS_MSEC) < start_time:
                continue
            elif video_capture.get(cv2.CAP_PROP_POS_MSEC) <= stop_time:
                frame_count+=1
                if frame_count%3 == 0:
                    print(i)
                    print('analysing '+file)
                    print(video_capture.get(cv2.CAP_PROP_POS_MSEC))
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                    faces = faceCascade.detectMultiScale(gray,scaleFactor=1.1)

                    # Draw a rectangle around the faces
                    for (x, y, w, h) in faces:
                        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2,5)
                        face_crop = frame[y:y+h,x:x+w]
                        face_crop = cv2.resize(face_crop,(48,48))
                        face_crop = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY)
                        face_crop = face_crop.astype('float32')/255
                        face_crop = np.asarray(face_crop)
                        face_crop = face_crop.reshape(1, 1,face_crop.shape[0],face_crop.shape[1])
                        result = target[np.argmax(model.predict(face_crop))]
                        cv2.putText(frame,result,(x,y), font, 1, (200,0,0), 3, cv2.LINE_AA)
                        total+=1
                        if(result=='happy'):
                            happy+=1
                        if(result=='angry'):
                            angry+=1
                        if(result=='disgust'):
                            disgust+=1
                        if(result=='fear'):
                            fear+=1
                        if(result=='sad'):
                            sad+=1
                        if(result=='neutral'):
                            neutral+=1
                        if(result=='surprise'):
                            surprise+=1
                        #cv2.imshow('Video', frame)
            
            else:
                break

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        except Exception as e:
            print(e)
            break
    # When everything is done, release the capture
    video_capture.release()
    #cv2.destroyAllWindows()
    print(total)
   

    happy=(happy/total)*100
    angry=(angry/total)*100
    sad=(sad/total)*100
    disgust=(disgust/total)*100
    fear=(fear/total)*100
    surprise=(surprise/total)*100
    neutral=(neutral/total)*100
    print(angry,disgust,fear,happy,sad,surprise,neutral)
    ns.write(i,4,angry)
    ns.write(i,5,disgust)
    ns.write(i,6,fear)
    ns.write(i,7,happy)
    ns.write(i,8,sad)
    ns.write(i,9,surprise)
    ns.write(i,10,neutral)
print('done')#(name of artist,name of song)
nb.save('Sheet_last_10.xls')










